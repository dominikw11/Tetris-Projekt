from settings import *
import math
from tetromino import Tetromino
import pygame.freetype as ft


class Text:
    def __init__(self, app):
        self.app = app
        self.font = ft.Font(FONT_PATH)
#zwraca kolor tekstu, który zmienia się dynamicznie w czasie. W tej funkcji użyto funkcji sinus do wyznaczenia koloru.
    def get_color(self):
        time = pg.time.get_ticks() * 0.001
        n_sin = lambda t: (math.sin(t) * 0.5 + 0.5) * 255
        return n_sin(time * 0.5), n_sin(time * 0.2), n_sin(time * 0.9)
#tekst po prawej stronie
    def draw(self):
        self.font.render_to(self.app.screen, (WIN_W * 0.595, WIN_H * 0.02),
                            text='TETRIS', fgcolor=self.get_color(),
                            size=TILE_SIZE * 1.65, bgcolor='black')
        self.font.render_to(self.app.screen, (WIN_W * 0.595, WIN_H * 0.1),
                            text='by Dominik Wierzbowski', fgcolor='white',
                            size=TILE_SIZE * 0.35, bgcolor='black')
        self.font.render_to(self.app.screen, (WIN_W * 0.69, WIN_H * 0.26),
                            text='next', fgcolor='orange',
                            size=TILE_SIZE * 1.4, bgcolor='black')
        self.font.render_to(self.app.screen, (WIN_W * 0.64, WIN_H * 0.65),
                            text='score', fgcolor='orange',
                            size=TILE_SIZE * 1.0, bgcolor='black')
        self.font.render_to(self.app.screen, (WIN_W * 0.64, WIN_H * 0.70),
                            text=f'{self.app.tetris.score}', fgcolor='white',
                            size=TILE_SIZE * 1.0)
        self.font.render_to(self.app.screen, (WIN_W * 0.64, WIN_H * 0.8),
                            text='highest score', fgcolor='pink',
                            size=TILE_SIZE * 0.6, bgcolor='black')
        self.font.render_to(self.app.screen, (WIN_W * 0.64, WIN_H * 0.83),
                            text=f'{self.app.high_score}', fgcolor='white',
                            size=TILE_SIZE * 0.5)

#Logika Gry
class Tetris:
    #inicjalizowanie zmiennych i obieiektów w grze: grupa sprite'ów, pole gry, bieżący i następny tetromino, wynik, ilość pełnych linii.
    def __init__(self, app):
        self.app = app
        self.sprite_group = pg.sprite.Group()
        self.field_array = self.get_field_array()
        self.tetromino = Tetromino(self)
        self.next_tetromino = Tetromino(self, current=False)
        self.speed_up = False
        self.score = 0
        self.full_lines = 0
        self.points_per_lines = {0: 0, 1: 100, 2: 300, 3: 700, 4: 1500}
#aktualizuje wynik gracza
    def get_score(self):
        self.score += self.points_per_lines[self.full_lines]
        self.full_lines = 0
        self.score += self.points_per_lines[self.full_lines]
        self.full_lines = 0
        if self.score > self.app.high_score:
            self.app.high_score = self.score
    def update_high_score(self):
        self.get_score()
        self.high_score = max(self.high_score, self.score)

#sprawdza, czy są jakieś pełne linie w grze i je usuwa
    def check_full_lines(self):
        row = FIELD_H - 1
        for y in range(FIELD_H - 1, -1, -1):
            for x in range(FIELD_W):
                self.field_array[row][x] = self.field_array[y][x]

                if self.field_array[y][x]:
                    self.field_array[row][x].pos = vec(x, y)

            if sum(map(bool, self.field_array[y])) < FIELD_W:
                row -= 1
            else:
                for x in range(FIELD_W):
                    self.field_array[row][x].alive = False
                    self.field_array[row][x] = 0

                self.full_lines += 1
# umieszcza blokina polu gry
    def put_tetromino_blocks_in_array(self):
        for block in self.tetromino.blocks:
            x, y = int(block.pos.x), int(block.pos.y)
            self.field_array[y][x] = block
#tworzy pole gry
    def get_field_array(self):
        return [[0 for x in range(FIELD_W)] for y in range(FIELD_H)]
#sprawdza, czy gra się skończyła
    def is_game_over(self):
        if self.tetromino.blocks[0].pos.y == INIT_POS_OFFSET[1]:
            pg.time.wait(300)
            return True
#sprawdza, czy bloki opadły na dół i czy można je usunąć
    def check_tetromino_landing(self):
        if self.tetromino.landing:
            if self.is_game_over():
                self.__init__(self.app)
            else:
                self.speed_up = False
                self.put_tetromino_blocks_in_array()
                self.next_tetromino.current = True
                self.tetromino = self.next_tetromino
                self.next_tetromino = Tetromino(self, current=False)
#przypisywanie ruchu klocków do klawiszy
    def control(self, pressed_key):
        if pressed_key == pg.K_LEFT:
            self.tetromino.move(direction='left')
        elif pressed_key == pg.K_RIGHT:
            self.tetromino.move(direction='right')
        elif pressed_key == pg.K_UP:
            self.tetromino.rotate()
        elif pressed_key == pg.K_DOWN:
            self.speed_up = True
#rysowanie kratek, iteracja przez wszystkie kratki
    def draw_grid(self):
        for x in range(FIELD_W):
            for y in range(FIELD_H):
                pg.draw.rect(self.app.screen, 'black',
                             (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE), 1)
#aktualizuje położenie i stan obiektów w grze
    def update(self):
        trigger = [self.app.anim_trigger, self.app.fast_anim_trigger][self.speed_up]
        if trigger:
            self.check_full_lines()
            self.tetromino.update()
            self.check_tetromino_landing()
            self.get_score()
        self.sprite_group.update()
#tworzenie kratek
    def draw(self):
        self.draw_grid()
        self.sprite_group.draw(self.app.screen)













